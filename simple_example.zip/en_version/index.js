window.addEventListener("load", () => {
  let myCaptha = new captchaCV("captcha");
  document.forms[0].addEventListener('submit', function(e){
    e.preventDefault();
    alert(myCaptha.verification());
   });
});